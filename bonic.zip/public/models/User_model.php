<?php
class user_model extends CI_Model
{
    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }

    //insert into user table
    function insertUser($data)
    {

        //name,phone,email,password,referrer,picture,country,state,acc_name,bank_name,acc_num,balance,bonus,role,cycle,rand
        return $this->db->insert('users', $data);
        //$ref_data = array(
        //'title' => 'My title',
        //'email' => $data['email'],
        //'ref_id' => $data['ref_id']
        //);
        //$this->db->insert('referral', $ref_data);
    }

    function sellCoin($data) {
      $this->db->set('role', '1');
      $this->db->set('book_bal', $this->session->ava_bal);
      $this->db->set('ava_bal', 'ava_bal -'.$data['amount'], FALSE);
      $this->db->where('id', $this->session->id);
      $this->db->update('users');
      $user = $this->getUserbyId($this->session->id);
      $this->session->set_userdata($user);
      return $this->db->insert('sales', $data);
    }

    function buyCoin($data) {
      extract($data);
      $this->db->set('role', '2');
      $this->db->where('id', $this->session->id);
      $this->db->update('users');
      $user = $this->getUserbyId($this->session->id);
      $this->session->set_userdata($user);
      $sales = $this->getAllSellers();
      foreach ($sales as $s) {
        // if buying amount is less than selling amount
        if ($amount < $s['amount']) {
          //merge the buyer with seller
            $arr = array(
              'seller_id' => $s['user_id'],
              'amount' => $amount,
              'buyer_id' => $user_id,
              'sales_id' => $s['id'],
              'time' => $time
            );
            $this->db->set($arr);
            $this->db->insert('merger');
            //compute seller's Balance
            $this->db->set('balance', "balance - $amount", FALSE);
            $this->db->where('id', $s['id']);
            $this->db->update('sales');
            break;
        }
        // if selling amount is less than buying amount
        if ($amount > $s['amount']) {
          //merge the buyer with seller
            $arr = array(
              'seller_id' => $s['user_id'],
              'amount' => $amount,
              'buyer_id' => $user_id,
              'sales_id' => $s['id'],
              'time' => $time
            );
            $this->db->set($arr);
            $this->db->insert('merger');
            //compute seller's Balance
            $this->db->set('balance', 0);
            $this->db->where('id', $s['id']);
            $this->db->update('sales');
        }
      }
      return 1;
    }

    function getUserPendingSale($user_id) {
      $this->db->where('user_id', $user_id);
      $this->db->where('status', 0);
      $res =  $this->db->get('sales')->result_array();
      return $res?$res[0]:null;
    }

    function getUserPendingPurchases($user_id) {
      $this->db->where('buyer_id', $user_id);
      //$this->db->where('status', 0);
      $res =  $this->db->get('merger')->result_array();
      return $res?$res:null;
    }

    function getMergeById($id){
        $this->db->where('id', $id);
        $res = $this->db->get('merger')->result_array();
        return $res?$res[0]:null;
    }

    function approvePayment($id){
      $this->db->set('status', 2);
      $this->db->where('id', $id);
      return $this->db->update('merger');
    }

    function getStageById($id){
      $this->db->where('id', $id);
      $res =  $this->db->get('stages')->result_array();
      return $res?$res[0]:null;
    }
    function getRequestMerges($id) {
      //$this->db->where('user_id', $user_id);
      $this->db->where('sales_id', $id);
      $res =  $this->db->get('merger')->result_array();
      return $res?$res:null;
    }

    function getAllSellers(){
      $this->db->where('status', 0);
      $this->db->where('balance >', 0);
      return $this->db->get('sales')->result_array();
    }

    //create new coin
    function addcoin($data)
    {
        return $this->db->insert('coins', $data);
    }

    function getUserReferrals($id){
      $this->db->where('referrer', $id);
      $result = $this->db->get('users')->result_array();
      return count($result)>0?$result:null;
    }

    function getAllUsers(){
      $result = $this->db->get('users')->result_array();
      return count($result)>0?$result:null;
    }

    function getAllSettings(){
      $result = $this->db->get('settings')->result_array();
      return count($result)>0?$result:null;
    }

    function getAppCurrency() {
        $this->db->where('id', 3);
        $result = $this->db->get('settings')->result_array();
        return $result[0];
    }

    function getAllCoins(){
      $result = $this->db->get('coins')->result_array();
      return count($result)>0?$result:null;
    }

    function updateAccount($params){
      $this->db->set($params);
      $this->db->where('id', $this->session->id);
      $update = $this->db->update('users');
      if ($update) {
        $this->session->set_userdata($params);
      }
      return $update?1:0;
    }

    //send verification email to user's email id
    function sendEmail($to_email)
    {
        $from_email = 'team@bonic.org';
        $subject = 'Verify Your Email Address';
        $message = 'Dear User,<br /><br />Please click on the below activation link to verify your email address.<br /><br /> http://www.bonic.org/user/verify/' . md5($to_email) . '<br /><br /><br />Thanks<br />Mydomain Team';

        //configure email settings
        $config['protocol'] = 'smtp';
        $config['smtp_host'] = 'ssl://smtp.bonic.org'; //smtp host name
        $config['smtp_port'] = '465'; //smtp port number
        $config['smtp_user'] = $from_email;
        $config['smtp_pass'] = '21Computer'; //$from_email password
        $config['mailtype'] = 'html';
        $config['charset'] = 'iso-8859-1';
        $config['wordwrap'] = TRUE;
        $config['newline'] = "\r\n"; //please, biko, I beg you, use double quotes
        $this->email->initialize($config);

        //send mail
        $this->email->from($from_email, 'Bonic');
        $this->email->to($to_email);
        $this->email->subject($subject);
        $this->email->message($message);
        return $this->email->send();
    }
    function isUseRegistered($email){
        $user = $this->db->get_where('users',array('email'=>$email))->result_array();
        return $user?1:0;
    }

    function checkIfIsAdmin($username, $password) {
      $query = $this->db->get_where('admin', array('username' =>$username, 'password' => md5($password)))->result_array();
      return count($query)>0?$query[0]:null;
    }

    function getUserbyId($id){
      $this->db->where('id', $id);
      $user = $this->db->get('users')->result_array();
      return count($user)> 0? $user[0]:null;
    }

    //To get user by referral id
    function getUserbyRand($rand)
    {
      $this->db->where('rand', $rand);
      $user = $this->db->get('users')->result_array();
      return count($user)> 0? $user[0]:null;
    }

    function isDetailsCorrect($email, $password){
        $user = $this->db->get_where('users',array('email'=>$email, 'password' => md5($password)))->result_array();
        return $user?$user[0]:0;
    }

    function createUserSession($userDetails) {
        $this->session->set_userdata($userDetails);
    }

    function createAdminSession($details) {
        $this->session->set_userdata($details);
    }

    //activate user account
    function verifyEmailID($key)
    {
        $data = array('status' => 1);
        $this->db->where('md5(email)', $key);
        return $this->db->update('user', $data);
    }

    //for FAQS delete
    function faq_delete($key)
    {
      # code...
    }

    //for FAQS update
    function faq_update($key)
    {

    }

    //for CRONJOBS
    function cronmodel($key)
    {
      //get total number of users
      //loop through users and check if start date and end date are the same
      //if they are the same, add bonus to the available balance
      //delete investment
    }

    //for referral bonus
    function bonus($key, $percentage)
    {
      //check if user has made a deposit
      //if deposit has been made, calculate bonus with the deposited amount
      //Insert bonus in referrral and
    }
}
?>