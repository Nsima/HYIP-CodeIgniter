<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		if(!$this->session->name){
			$this->session->set_flashdata('msg','<div class="alert alert-success text-center">Login to continue!!!</div>');
			redirect(base_url('login'));
		};
	}
	public function index()
	{
		if($this->session->cycle == 0){
			//redirect('market');
		};
		//if user is selling
		if ($this->session->role == 1) {
				$req = $this->User_model->getUserPendingSale($this->session->id);
				$pagedata['merges'] =  $this->User_model->getRequestMerges($req['id']);
		}
		//if user is buying
		if ($this->session->role == 2) {
				$req = $this->User_model->getUserPendingPurchases($this->session->id);
				$pagedata['merges'] =  $req;
		}
		$pagedata['sellers'] = $this->User_model->getAllSellers();		
		$pagedata['title'] = 'Dashboard';
		$this->load->view('includes/dashboard_header', $pagedata);
		$this->load->view('user/dashboard');
		$this->load->view('includes/dashboard_footer');
	}
	public function deposit()
	{
		$pagedata['title'] = 'Deposit';
		$this->load->view('includes/dashboard_header', $pagedata);
		$this->load->view('user/deposit');
		$this->load->view('includes/dashboard_footer');
	}
	public function market()
	{
		//if user is selling
		if ($this->session->role == 1) {
				$req = $this->User_model->getUserPendingSale($this->session->id);
				$pagedata['merges'] =  $this->User_model->getRequestMerges($req['id']);
		}
		//if user is buying
		if ($this->session->role == 2) {
				$req = $this->User_model->getUserPendingPurchases($this->session->id);
				$pagedata['merges'] =  $req;
		}
		$pagedata['sellers'] = $this->User_model->getAllSellers();
		$pagedata['title'] = 'Market';
		$this->load->view('includes/dashboard_header', $pagedata);
		$this->load->view('user/market');
		$this->load->view('includes/dashboard_footer');
	}

	function approve_merge() {
		if (isset($_POST['approve'])) {
			extract($_POST);
			$merge = $this->User_model->getMergeById($merge_id);
			$approve = $this->User_model->approvePayment($merge_id);
			if ($approve) {
				//update the buyers Account
			$this->db->set('book_bal', 'book_bal +'.$merge['amount'], FALSE);
			$this->db->set('cycle', 1);
			$this->db->set('role', 2);
			$this->db->where('id', $merge['buyer_id']);
			$this->db->update('users');
			//update the seller's account
			$this->db->set('book_bal', 'book_bal -'.$merge['amount'], FALSE);
			$this->db->set('cycle', 1);
			$this->db->where('id', $merge['seller_id']);
			$this->db->update('users');
			$this->session->set_flashdata('msg','<div class="alert alert-success alert-dismissible" role="alert">
							<button type="button" class="close" data-dismiss="alert">×</button>
								<div class="alert-icon">
									<i class="icon-info"></i>
								</div>
							<div class="alert-message">
							<span>Payment approved!!!</span>
							</div>
						</div>');
			redirect('market');
		}else{
			$this->session->set_flashdata('msg','<div class="alert alert-danger alert-dismissible" role="alert">
                <button type="button" class="close" data-dismiss="alert">×</button>
                  <div class="alert-icon">
                    <i class="icon-info"></i>
                  </div>
                <div class="alert-message">
                <span>The request was not successful. Please contact the admin!!!</span>
                </div>
              </div>');
				redirect('user');
		}
		}
	}

	function upload_proof() {
		if(isset($_POST['upload'])){
			extract($_POST);
			//var_dump($_POST);
			//die();
			$target_dir = "proofs/";//folder to save image
			//echo $target_dir;
			//die();
			$filename = basename($_FILES["proof"]["name"]);
			$targetFilePath = $target_dir . $filename;

			$fileType = pathinfo($targetFilePath,PATHINFO_EXTENSION);

			$allowTypes = array('jpg','png','jpeg','gif','pdf');
			// Check file size
			if ($_FILES["proof"]["size"] > 500000) {
				$this->session->set_flashdata('msg','Sorry, your file is too large.');
				redirect('market');
			}
			if(!in_array($fileType,$allowTypes)){
				$this->session->set_flashdata('msg','The file type is not allowed,please select only jpg,png or jpeg pictures');
				redirect('market');
			}else{
				//turn the image name into array
				$array = explode('.',$filename);
				//get the extension
				$ext = end($array);
				//rename the file
				$name = md5(time());
				//put it all together
				$newfilename = $name.'.'.$ext;
				//absolute path to the rename image
				$target_file = $target_dir .$newfilename;
				//upload to the proofs folder
				//echo $_FILES["proof"]["tmp_name"];
				//echo $newfilename;

				//$tre = move_uploaded_file($_FILES["proof"]["tmp_name"], $target_file);
				//echo $tre;
			//die();

				if (move_uploaded_file($_FILES["proof"]["tmp_name"], $target_file)){
					$data = array(
						'status' => 1,
						'proof' => $newfilename
							   );
					$this->db->set($data);
					$this->db->where('id', $merge_id);
					$this->db->update('merger');
					$this->session->set_flashdata('msg','Proof uploaded successfully');
				redirect('market');

				}else{
					$this->session->set_flashdata('msg','could not upload proof ');
				redirect('market');
				}
			}
		}
	}
	function sell_coins() {
			extract($this->input->post());
			if($qty > $this->session->ava_bal) {
				$this->session->set_flashdata('msg','<div class="alert alert-danger alert-dismissible" role="alert">
                <button type="button" class="close" data-dismiss="alert">×</button>
                  <div class="alert-icon">
                    <i class="icon-info"></i>
                  </div>
                <div class="alert-message">
                <span>You cannot sell more than your available balance!!!</span>
                </div>
              </div>');
				redirect('user');
			}
			$data = array(
				'user_id' => $this->session->id,
				'amount' => $qty,
				'balance'=> $qty,
				'time' => time()
			);
			$insert = $this->User_model->sellCoin($data);
			if ($insert) {
				$this->session->set_flashdata('msg','<div class="alert alert-info alert-dismissible" role="alert">
                <button type="button" class="close" data-dismiss="alert">×</button>
                  <div class="alert-icon">
                    <i class="icon-info"></i>
                  </div>
                <div class="alert-message">
                <span>Your sell request has been submitted!!!</span>
                </div>
              </div>');
				redirect('market');
			}else{
				$this->session->set_flashdata('msg','<div class="alert alert-danger alert-dismissible" role="alert">
                <button type="button" class="close" data-dismiss="alert">×</button>
                  <div class="alert-icon">
                    <i class="icon-info"></i>
                  </div>
                <div class="alert-message">
                <span>could not complete the request, please try again later!!!</span>
                </div>
              </div>');
				redirect('user');
			}
	}

	function buy_coins() {
				extract($this->input->post());
				$stage = $this->session->stage;
				$currency = $this->User_model->getAppCurrency();
				$stageDetails =  $this->User_model->getStageById($stage);
				if($qty > $stageDetails['amount']) {
					$this->session->set_flashdata('msg','<div class="alert alert-danger alert-dismissible" role="alert">
	                <button type="button" class="close" data-dismiss="alert">×</button>
	                  <div class="alert-icon">
	                    <i class="icon-info"></i>
	                  </div>
	                <div class="alert-message">
	                <span>You cannot buy more than '.$currency['value'].$stageDetails['amount'] .' at your current level!!!</span>
	                </div>
	              </div>');
					redirect('user');
				}
				if($qty < $stageDetails['amount']) {
					$this->session->set_flashdata('msg','<div class="alert alert-danger alert-dismissible" role="alert">
	                <button type="button" class="close" data-dismiss="alert">×</button>
	                  <div class="alert-icon">
	                    <i class="icon-info"></i>
	                  </div>
	                <div class="alert-message">
	                <span>You cannot buy less than '.$currency['value'].$stageDetails['amount'] .' at your current level!!!</span>
	                </div>
	              </div>');
					redirect('user');
				}

				$data = array(
					'user_id' => $this->session->id,
					'amount' => $qty,
					'time' => time()
				);
				$insert = $this->User_model->buyCoin($data);
				if ($insert) {
					$this->session->set_flashdata('msg','<div class="alert alert-info alert-dismissible" role="alert">
	                <button type="button" class="close" data-dismiss="alert">×</button>
	                  <div class="alert-icon">
	                    <i class="icon-info"></i>
	                  </div>
	                <div class="alert-message">
	                <span>Your buy request has been approved!!!</span>
	                </div>
	              </div>');
					redirect('market');
				}else{
					$this->session->set_flashdata('msg','<div class="alert alert-danger alert-dismissible" role="alert">
	                <button type="button" class="close" data-dismiss="alert">×</button>
	                  <div class="alert-icon">
	                    <i class="icon-info"></i>
	                  </div>
	                <div class="alert-message">
	                <span>could not complete the request, please try again later!!!</span>
	                </div>
	              </div>');
					redirect('user');
				}
		}

	public function referral()
	{
		if($this->session->cycle == 0){
			redirect('market');
		};
		$pagedata['title'] = 'Referral';
		$pagedata['referrals'] = $this->User_model->getUserReferrals($this->session->id);
		$this->load->view('includes/dashboard_header', $pagedata);
		$this->load->view('user/referral');
		$this->load->view('includes/dashboard_footer');
	}
	public function transfer()
	{
		$pagedata['title'] = 'Transfer';
		$this->load->view('includes/dashboard_header', $pagedata);
		$this->load->view('user/transfer');
		$this->load->view('includes/dashboard_footer');

	}
	public function profile()
	{
		$pagedata['title'] = 'Profile';
		$pagedata['name'] = $this->session->name;
		$pagedata['email'] = $this->session->email;
		$this->load->view('includes/dashboard_header', $pagedata);
		$this->load->view('user/profile');
		$this->load->view('includes/dashboard_footer');
	}

	function editprofile() {
		if (isset($_POST['update'])) {
			extract($this->input->post());
			$data = array(
				'name' => $name,
				'email' => $email,
				'phone' => $phone,
				'acc_num' => $acc_num,
				'acc_name' => $acc_name,
				'bank_name' => $bank_name
			);

			$update = $this->User_model->updateAccount($data);
			if($update) {
					$this->session->set_flashdata('editMessage', "Your changes have been saved");
					redirect('profile');
			}else{
				$this->session->set_flashdata('editMessage', "Your changes could not be saved. Please try again later!");
					redirect('profile');
			}
		}else{
			$this->session->set_flashdata('editMessage', "Fields cannot be empty");
					redirect('profile');
		}
	}
	public function login_history()
	{
		if($this->session->cycle == 0){
			redirect('market');
		};
		$pagedata['title'] = 'Login History';
		$this->load->view('includes/dashboard_header', $pagedata);
		$this->load->view('user/login-history');
		$this->load->view('includes/dashboard_footer');
	}
	public function support()
	{
		if($this->session->cycle == 0){
			redirect('market');
		};
		$pagedata['title'] = 'Support';
		$this->load->view('includes/dashboard_header', $pagedata);
		$this->load->view('user/support');
		$this->load->view('includes/dashboard_footer');
	}

	public function getChart() {
		$res = $this->db->get('chart')->result_array();
		echo $res?json_encode($res):null;
	}
	public function logout()
	{
		$this->session->sess_destroy();
		redirect(base_url('login'));
	}
}