<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		if (!$this->session->admin) {
			redirect('auth');
		}
	}
	public function index()
	{
		$pagedata['title'] = 'Admin | Dashboard';
		$pagedata['users']  = $this->User_model->getAllUsers();
		$this->load->view('admin/header', $pagedata);
		$this->load->view('admin/main');
		$this->load->view('admin/footer');
	}

	public function coins() {
			$pagedata['title'] = 'Admin | Coin Settings';
			$pagedata['coins']  = $this->User_model->getAllCoins();
			$this->load->view('admin/header', $pagedata);
			$this->load->view('admin/coins');
			$this->load->view('admin/footer');
	}

	public function FAQS() {
			$pagedata['title'] = 'Admin | FAQS';
			$pagedata['faqs'] = $this->User_model->faqs();
			$this->load->view('admin/header', $pagedata);
			$this->load->view('admin/faqs');
			$this->load->view('admin/footer');
	}

	public function addcoin() {
		if (is_array($this->input->post())) {
			extract($this->input->post());
			$data =  array(
				'name' => $name,
				'alias' => $alias,
				'quantity' => $qty,
				'qty_in_circ' => $qty_in_circ,
				'rate' => $rate
			);
			$add = $this->User_model->addcoin($data);
			if ($add) {
				$this->session->set_flashdata('message', "New coin successfully added");
					redirect('admin/coins');
			}else {
				$this->session->set_flashdata('message', "Could not complete the request");
					redirect('admin/coins');
			}
		}
	}

	function edit_coins() {
		extract($_POST);
		$data  = array($name => $value);
		$this->db->where('id', $pk);
		$this->db->set($data);
		$this->db->update('coins');
	}

	function delete_coin($id) {
		$this->db->where('id', $id);
		$del = $this->db->delete('coins');
		if ($del) {
			$this->session->set_flashdata('message', "The coin has been deleted");
					redirect('admin/coins');
		}else {
			$this->session->set_flashdata('message', "Could not complete the request");
					redirect('admin/coins');
		}
	}

	public function settings() {
		$pagedata['title'] = 'Admin | Settings';
		$pagedata['settings']  = $this->User_model->getAllSettings();
		$this->load->view('admin/header', $pagedata);
		$this->load->view('admin/settings');
		$this->load->view('admin/footer');
	}

	function edit_settings() {
		extract($_POST);
		$data  = array($name => $value);
		$this->db->where('id', $pk);
		$this->db->set($data);
		$this->db->update('settings');
	}

	function delete_user($id) {
		$this->db->where('id', $id);
		$del = $this->db->delete('users');
		if ($del) {
			$this->session->set_flashdata('message', "The user has been deleted");
					redirect('admin');
		}else {
			$this->session->set_flashdata('message', "Could not complete the request");
					redirect('admin');
		}
	}

	public function logout()
	{
		$this->session->sess_destroy();
		redirect('auth');
	}

	public function profile()
	{
		$this->load->view('includes/dashboard_header');
		$this->load->view('profile');
		$this->load->view('includes/dashboard_footer');
	}
	public function signup()
	{
		$this->load->view('includes/dashboard_header');
		$this->load->view('signup');
		$this->load->view('includes/dashboard_footer');
	}
	public function blog()
	{
		$this->load->view('includes/dashboard_header');
		$this->load->view('blog');
		$this->load->view('includes/dashboard_footer');
	}
	public function blog_post()
	{
		$this->load->view('includes/dashboard_header');
		$this->load->view('blog-post');
		$this->load->view('includes/dashboard_footer');
	}
}
