<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Auth extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
	}
	public function index()
	{
    $this->load->view('includes/front_header');
		$this->load->view('admin/login');
		$this->load->view('includes/front_footer');
	}

  	public function do_login() 
  	{
      if (isset($_POST)) {
          extract($_POST);
          $check = $this->User_model->checkIfIsAdmin($username, $password);
          if (!$check) {
              $this->session->set_flashdata('msg','<div class="alert alert-danger text-center">Oops! Error.  We could not find any user with the combination provided!!!</div>');
              redirect('auth/login');
          }else{
              $startSession = $this->User_model->createAdminSession($check);
              redirect('admin');
          }
      }else{
          die("THIS ACTION IS NOT ALLOWED");
      }
  	}
  	
	public function profile()
	{
		$this->load->view('includes/dashboard_header');
		$this->load->view('profile');
		$this->load->view('includes/dashboard_footer');
	}
	public function signup()
	{
		$this->load->view('includes/dashboard_header');
		$this->load->view('signup');
		$this->load->view('includes/dashboard_footer');
	}
	public function blog()
	{
		$this->load->view('includes/dashboard_header');
		$this->load->view('blog');
		$this->load->view('includes/dashboard_footer');
	}
	public function blog_post()
	{
		$this->load->view('includes/dashboard_header');
		$this->load->view('blog-post');
		$this->load->view('includes/dashboard_footer');
	}
}
