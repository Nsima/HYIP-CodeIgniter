<div class="clearfix"></div>
<div class="content-wrapper">
  <div class="container-fluid">
    <div class="row justify-content-center">
      <div class="col-md-12">
        <div class="card">
          <div class="card-header">
            <h5>Coin Settings</h5>
            <?php if (($this->session->flashdata('message'))) {?>
              <div class="alert alert-dismissible">
                <p><?=$this->session->flashdata('message')?></p>
              </div>
            <?php } ?>
          </div>
          <div class="card-body">
              <div class="row">
                <div class="col-md-12">
                  <div class="card">
                    <div class="card-header">
                      Coin Listing
                      <span
                        class="pull-right btn btn-success"
                        data-toggle="modal"
                        data-target="#coinModal"
                      >
                        <i class="fa fa-plus"></i>
                        Add New Coin
                      </span>
                    </div>
                    <div class="card-body">
                      <div class="table-responsive">
                        <table class="table align-items-center table-flush table-borderless">
                            <thead>
                              <tr>
                                <th>No</th>
                                <th>Name</th>
                                <th>Alias</th>
                                <th>Total Quantity</th>
                                <th>Quantity in Circulation</th>
                                <th>Rate</th>
                                <th>Action</th>
                              </tr>
                            </thead>
                            <tbody>
                              <?php if (is_array($coins)) {
                                $count = 1;
                                foreach ($coins as $c) {?>
                                  <tr>
                                    <td><?=$count++?></td>
                                    <td>
                                      <a
                                        href="#"
                                        class="editable"
                                        data-type="text"
                                        data-pk="<?=$c['id']?>"
                                        data-url="<?=base_url('admin/edit_coins')?>"
                                        data-name="name"
                                        />
                                        <?=$c['name']?>
                                      </a>
                                    </td>
                                    <td>
                                      <a
                                        href="#"
                                        class="editable"
                                        data-type="text"
                                        data-pk="<?=$c['id']?>"
                                        data-url="<?=base_url('admin/edit_coins')?>"
                                        data-name="alias"
                                        />
                                        <?=$c['alias']?>
                                      </a>
                                    </td>
                                    <td>
                                      <a
                                        href="#"
                                        class="editable"
                                        data-type="text"
                                        data-pk="<?=$c['id']?>"
                                        data-url="<?=base_url('admin/edit_coins')?>"
                                        data-name="quantity"
                                        />
                                        <?=$c['quantity']?>
                                      </a>
                                    </td>
                                    <td>
                                      <a
                                        href="#"
                                        class="editable"
                                        data-type="text"
                                        data-pk="<?=$c['id']?>"
                                        data-url="<?=base_url('admin/edit_coins')?>"
                                        data-name="qty_in_circ"
                                        />
                                        <?=$c['qty_in_circ']?>
                                      </a>
                                    </td>
                                    <td>
                                      <a
                                        href="#"
                                        class="editable"
                                        data-type="text"
                                        data-pk="<?=$c['id']?>"
                                        data-url="<?=base_url('admin/edit_coins')?>"
                                        data-name="rate"
                                        />
                                        <?=$c['rate']?>
                                      </a>
                                    </td>
                                    <td><a href="<?=base_url("admin/delete_coin/".$c['id'])?>" class="btn btn-danger">Delete Coin</a></td>
                                  </tr>
                              <?php } } ?>
                            </tbody>
                        </table>
                      </div>
                      <div class="modal fade" id="coinModal" tabindex="-1" role="dialog" aria-labelledby="coinModalLabel">
                        <div class="modal-dialog" role="document">
                          <div class="modal-content bg-primary">
                            <div class="modal-header">
                              <p class="modal-title" id="coinModalLabel">Add New Coin</p>
                              <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                            </div>
                            <div class="modal-body">
                              <form action="<?=base_url('admin/addcoin')?>" method="post">
                                <div class="form-group">
                                  <label for="coin-name" class="control-label">Name:</label>
                                  <input type="text" name="name" class="form-control" id="coin-name">
                                </div>
                                <div class="form-group">
                                  <label for="alias" class="control-label">Alias:</label>
                                  <input type="text" class="form-control" id="alias" name="alias" />
                                </div>
                                <div class="form-group">
                                  <label for="qty" class="control-label">Quantity:</label>
                                  <input type="text" class="form-control" id="qty" name="qty" />
                                </div>
                                <div class="form-group">
                                  <label for="qty_in_circ" class="control-label">Quantity in Circulation:</label>
                                  <input type="text" class="form-control" id="qty_in_circ" name="qty_in_circ" />
                                </div>
                                <div class="form-group">
                                  <label for="rate" class="control-label">Rate:</label>
                                  <input type="text" class="form-control" id="rate" name="rate" />
                                </div>
                                <button type="submit" class="btn btn-secondary btn-block">Submit</button>
                              </form>
                            </div>
                            <div class="modal-footer">
                              <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>

                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
