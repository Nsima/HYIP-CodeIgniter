                            <div class="faq-accordion">
                                <div class="accrodion-grp"  data-grp-name="faq-accrodion">
                                    <?php foreach ($faqs as $row) { ?>
                                    <div class="accrodion animated wow fadeInRight" data-wow-duration="1500ms" data-wow-delay="0ms">
                                        <div class="accrodion-inner">
                                            <div class="accrodion-title">
                                                <h4><?=$row->title;?></h4>
                                            </div>
                                            <div class="accrodion-content">
                                                <div class="inner">
                                                    <p><?=$row->content;?></p>
                                                </div><!-- /.inner -->
                                            </div>
                                        </div><!-- /.accrodion-inner -->
                                    </div>
                                    <?php }  ?>
                                </div>
                            </div>