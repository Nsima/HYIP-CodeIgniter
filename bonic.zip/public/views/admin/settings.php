<div class="clearfix"></div>
<div class="content-wrapper">
  <div class="container-fluid">
    <div class="row justify-content-center">
      <div class="col-md-12">
        <div class="card">
          <div class="card-header">
            <h5>Settings</h5>
            <?php if (($this->session->flashdata('message'))) {?>
              <div class="alert alert-dismissible">
                <p><?=$this->session->flashdata('message')?></p>
              </div>
            <?php } ?>
          </div>
          <div class="card-body">
              <div class="row">
                <div class="col-md-12">
                  <div class="card">
                    <div class="card-header">
                      settings
                    </div>
                    <div class="card-body">
                      <div class="table-responsive">
                        <table class="table align-items-center table-flush table-borderless">
                            <thead>
                              <tr>
                                <th>No</th>
                                <th>Item</th>
                                <th>Value</th>
                                <!--<th>Edit</th>-->
                              </tr>
                            </thead>
                            <tbody>
                              <?php if (is_array($settings)) {
                                $count = 1;
                                foreach ($settings as $s) {?>
                                  <tr>
                                    <td><?=$count++?></td>
                                    <td>
                                      <a
                                        href="#"
                                        class="editable"
                                        data-type="text"
                                        data-pk="<?=$s['id']?>"
                                        data-url="<?=base_url('admin/edit_settings')?>"
                                        data-name="item"
                                        />
                                        <?=$s['item']?>
                                      </a>
                                    </td>
                                    <td>
                                      <a
                                        href="#"
                                        class="editable"
                                        data-type="text"
                                        data-pk="<?=$s['id']?>"
                                        data-url="<?=base_url('admin/edit_settings')?>"
                                        data-name="value"
                                        />
                                        <?=$s['value']?>
                                      </a>
                                    </td>
                                    <!--<td><a href="<?=base_url("admin/edit_settings/".$s['id'])?>" class="btn btn-danger">Edit</a></td>-->
                                  </tr>
                              <?php } } ?>
                            </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
