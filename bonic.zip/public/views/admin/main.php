<div class="clearfix"></div>
<div class="content-wrapper">
  <div class="container-fluid">
    <div class="row justify-content-center">
      <div class="col-md-12">
        <div class="card">
          <div class="card-header">
            <h5>Site Analytics</h5>
            <?php if (($this->session->flashdata('message'))) {?>
              <div class="alert alert-dismissible">
                <p><?=$this->session->flashdata('message')?></p>
              </div>
          <?php } ?>
          </div>
          <div class="card-body">
              <div class="row">
                <div class="col-md-4">
                  <div class="card">
                    <div class="card-header">
                      Number of registered users
                    </div>
                    <div class="card-body">
                      <?=count($users)?>
                    </div>
                  </div>
                </div>
                <div class="col-md-4">
                  <div class="card">
                    <div class="card-header">
                      Number of Deposits
                    </div>
                    <div class="card-body">
                      0
                    </div>
                  </div>
                </div>
                <div class="col-md-4">
                  <div class="card">
                    <div class="card-header">
                      Number of Withdrawals
                    </div>
                    <div class="card-body">
                      0
                    </div>
                  </div>
                </div>
              </div>
          </div>
        </div>
      </div>
    </div>
    <div class="row justify-content-center">
      <div class="col-md-12">
        <div class="card">
          <div class="card-header">
            <h5>Users</h5>
            <?php if (($this->session->flashdata('message'))) {?>
              <div class="alert alert-dismissible">
                <p><?=$this->session->flashdata('message')?></p>
              </div>
            <?php } ?>
          </div>
          <div class="card-body">
              <div class="row">
                <div class="col-md-12">
                  <div class="card">
                    <div class="card-header">
                      Users Table
                    </div>
                    <div class="card-body">
                      <div class="table-responsive">
                        <table class="table align-items-center table-flush table-borderless">
                            <thead>
                              <tr>
                                <th>No</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Phone</th>
                                <th>Action</th>
                              </tr>
                            </thead>
                            <tbody>
                              <?php if (is_array($users)) {
                                $count = 1;
                                foreach ($users as $u) {?>
                                  <tr>
                                    <td><?=$count++?></td>
                                    <td><?=$u['name']?></td>
                                    <td><?=$u['email']?></td>
                                    <td><?=$u['phone']?></td>
                                    <td><a href="<?=base_url("admin/delete_user/".$u['id'])?>" class="btn btn-danger">Delete</a></td>
                                  </tr>
                              <?php } } ?>
                            </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
