    </div>
  <!--start overlay-->
      <div class="overlay toggle-menu"></div>
    <!--end overlay-->
    

    <!-- End container-fluid-->
    
    </div><!--End content-wrapper-->
   <!--Start Back To Top Button-->
    <a href="javaScript:void();" class="back-to-top"><i class="fa fa-angle-double-up"></i> </a>
    <!--End Back To Top Button-->
  
  <!--Start footer-->
  <footer class="footer">
      <div class="container">
        <div class="text-center">
          Copyright © 2020 <?=config_item('app_name');?>
        </div>
      </div>
    </footer>
  <!--End footer-->

   
  </div><!--End wrapper-->

  <!-- Bootstrap core JavaScript-->
  <script src="<?php echo config_item('base_url'); ?>dash/assets/js/jquery.min.js"></script>
  <script src="<?php echo config_item('base_url'); ?>dash/assets/js/popper.min.js"></script>
  <script src="<?php echo config_item('base_url'); ?>dash/assets/js/bootstrap.min.js"></script>

 <!-- simplebar js -->
  <script src="<?php echo config_item('base_url'); ?>dash/assets/plugins/simplebar/js/simplebar.js"></script>
  <!-- sidebar-menu js -->
  <script src="<?php echo config_item('base_url'); ?>dash/assets/js/sidebar-menu.js"></script>
  <!-- loader scripts -->
  <script src="<?php echo config_item('base_url'); ?>dash/assets/js/jquery.loading-indicator.js"></script>
  <!-- Custom scripts -->
  <script src="<?php echo config_item('base_url'); ?>dash/assets/js/app-script.js"></script>
  <!-- Chart js -->

  <script src="<?php echo config_item('base_url'); ?>dash/assets/plugins/Chart.js/Chart.min.js"></script>
 <?php
		$ci =& get_instance();
		$c = $ci->router->fetch_class();
		$m = $ci->router->fetch_method();
		if($c == 'User' && $m == 'index') {
  ?>
  <!-- Index js -->
  <script src="<?php echo config_item('base_url'); ?>dash/assets/js/index.js"></script>
	<?php } ?>

</body>
</html>
