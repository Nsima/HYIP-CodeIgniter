<div class="clearfix"></div>

  <div class="content-wrapper">
    <div class="container-fluid">
      <?php  if ($this->session->flashdata('msg')) {
        echo $this->session->flashdata("msg");
      }?>
  <!--Start Market Content-->
      <div class="row justify-content-center">
        <?php if($this->session->role == 2){?>
        <div class="col-lg-10">
          <div class="card">
            <div class="card-body">
              <h5 class="card-title">My Purchases</h5>
			  <div class="table-responsive">
              <table class="table table-hover">
                <thead>
                  <tr>
                    <th scope="col">#</th>
                    <th scope="col">Amount ($)</th>
                    <th scope="col">Buying from</th>
                    <th>Expires in</th>
                    <th scope="col">Action</th>
                  </tr>
                </thead>
                <tbody>
                  <?php if (is_array($merges)) {
                    $count = 1;
                    foreach ($merges as $m) {
                      $seller = $this->User_model->getUserbyId($m['seller_id']);
                      ?>
                  <tr>
                    <th scope="row"><?=$count++?></th>
                    <td><?=$m['amount']?></td>
                    <td>
                      <button type="button"
                        class="btn btn-success btn-sm"
                        data-toggle='modal'
                        data-target='#seller<?=$m['id']?>'
                      >
                        <?=$seller['name']?>
                      </button>
                      <div class="modal fade" id="seller<?=$m['id']?>" tabindex="-1" role="dialog" aria-labelledby="seller<?=$m['id']?>Label">
                        <div class="modal-dialog" role="document">
                          <div class="modal-content bg-primary">
                            <div class="modal-header">
                              <p class="modal-title" id="coinModalLabel">Seller Account Details</p>
                              <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                            </div>
                            <div class="modal-body">
                                <div class="form-group">
                                  <label for="acc_name" class="control-label">Account Name</label>
                                  <input type="text" readonly class="form-control"  value="<?=$seller['acc_name']?>">
                                </div>
                                <div class="form-group">
                                  <label for="acc_num" class="control-label">Account Number</label>
                                  <input type="text" readonly class="form-control" value="<?=$seller['acc_num']?>">
                                </div>
                                <div class="form-group">
                                  <label for="bank" class="control-label">Bank</label>
                                  <input type="text" class="form-control" readonly value="<?=$seller['bank_name']?>">
                                </div>
                            </div>
                            <div class="modal-footer">
                              <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>

                            </div>
                          </div>
                        </div>
                      </div>
                    </td>
                    <td id="timer<?=$m['id']?>">
                      <?php if ($m['status'] == 0): ?>
                        <script>
                           startTimer('timer<?php echo $m['id']; ?>','360','<?php echo date('M j, Y H:i:s',$m['time']); ?>','<?php echo $m['id']; ?>');
                        </script>
                      <?php else: ?>

                      <?php endif; ?>

                    </td>
                    <td>
                      <?php if ($m['status'] == 0): ?>
                        <button
                          type="button"
                          class="btn btn-success btn-sm"
                          data-toggle='modal'
                          data-target='#confirm<?=$m['id']?>'
                          >
                          confirm
                        </button>
                      <?php elseif ($m['status'] == 1): ?>
                        <a href="#" class="btn btn-sm btn-warning">
                          awaiting approval
                        </a>
                      <?php else: ?>
                        <button
                          type="button"
                          disabled
                          class="btn btn-success btn-sm"
                          >
                          approved
                        </button>
                      <?php endif; ?>
                      <div class="modal fade" id="confirm<?=$m['id']?>" tabindex="-1" role="dialog" aria-labelledby="confirm<?=$m['id']?>Label">
                        <div class="modal-dialog" role="document">
                          <div class="modal-content bg-primary">
                            <div class="modal-header">
                              <p class="modal-title" id="coinModalLabel">Upload Proof</p>
                              <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                            </div>
                            <div class="modal-body">
                              <form action="<?=base_url('user/upload_proof')?>" method="post" enctype="multipart/form-data">
                                <div class="form-group">
                                  <label for="proof" class="control-label">Upload Proof:</label>
                                  <input type="hidden" name="merge_id" value="<?=$m['id']?>">
                                  <input type="file" name="proof" class="form-control" id="proof">
                                </div>
                                <button type="submit" name="upload" class="btn btn-secondary btn-block">Submit</button>
                              </form>
                            </div>
                            <div class="modal-footer">
                              <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>

                            </div>
                          </div>
                        </div>
                      </div>
                    </td>
                  </tr>
                <?php } } ?>
                </tbody>
              </table>
            </div>
            </div>
          </div>
        </div>
      <?php } ?>
      <?php if ($this->session->role == 1) {?>
        <div class="col-lg-10">
          <div class="card">
            <div class="card-body">
              <h5 class="card-title">My Sales</h5>
        <div class="table-responsive">
              <table class="table table-hover">
                <thead>
                  <tr>
                    <th scope="col">#</th>
                    <th scope="col">Amount ($)</th>
                    <th scope="col">Selling To</th>
                    <th>Expires in</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>

                  <?php if (is_array($merges)) {
                    $count = 1;
                    foreach ($merges as $m) {
                      $buyer = $this->User_model->getUserbyId($m['buyer_id']);
                      ?>
                  <tr>
                    <th scope="row"><?=$count++?></th>
                    <td><?=$m['amount']?></td>
                    <td><?=$buyer['name']?></td>
                    <td id="timer<?=$m['id']?>">
                      <?php if ($m['status'] == 0): ?>
                        <script>
                           startTimer('timer<?php echo $m['id']; ?>','360','<?php echo date('M j, Y H:i:s',$m['time']); ?>','<?php echo $m['id']; ?>');
                        </script>
                      <?php else: ?>
                        Paid
                      <?php endif; ?>
                    </td>
                    <td>
                      <?php if ($m['status'] == 0): ?>
                        <button
                          type="button"
                          class="btn btn-success btn-sm"
                          disabled
                          >
                          Awaiting Payment
                        </button>
                      <?php elseif ($m['status'] == 1): ?>
                        <form action="<?=base_url('user/approve_merge')?>" method="post">
                          <input type="hidden" name="merge_id" value="<?=$m['id']?>">
                          <button type="submit" class="btn btn-success btn-sm" name="approve">Approve</button>
                        </form>
                      <?php else: ?>
                        <button
                          type="button"
                          disabled
                          class="btn btn-success btn-sm"
                          >
                          Approved
                        </button>
                      <?php endif; ?>
                    </td>
                  </tr>
                <?php } }else{?>
                  <tr>
                    <th scope="row"></th>
                    <td colspan="3" class="text-center"><span class="badge badge-info">Merge Pending</span></td>
                  </tr>
                <?php }?>
                </tbody>
              </table>
            </div>
            </div>
          </div>
        </div>
      <?php } ?>
      </div>
  <div class="row">
     <div class="col-12 col-lg-12">
       <div class="card">
         <div class="card-header">Market Place Overview
        <div class="card-action">
               <div class="dropdown">
                <div class="dropdown-menu dropdown-menu-right">
                 </div>
                </div>
               </div>
       </div>
           <div class="table-responsive">
                   <table class="table align-items-center table-flush table-borderless">
                    <thead>
                     <tr>
                       <th>Username</th>
                       <th>Photo</th>
                       <th>Account</th>
                       <th>Amount</th>
                       <th>Progress</th>
                     </tr>
                     </thead>
                     <tbody>
                       <?php if (is_array($sellers)) {
                         foreach ($sellers as $seller) {
                           $user = $this->User_model->getUserbyId($seller['user_id']);
                           ?>
                           <tr>
                            <td><?=$user['rand']?></td>
                            <td><span class="user-profile"><img src="<?=config_item('base_url');?>dash/uploads/110.png" class="img-circle" alt=""></span></td>
                            <td><?=$user['acc_num']?></td>
                            <td>$<?=number_format($seller['amount'])?></td>
                            <td><div class="progress shadow" style="height: 3px;">
                                <div class="progress-bar" role="progressbar" style="width: 90%"></div>
                                </div>
                            </td>
                           </tr>
                         <?php } } ?>
                   </tbody>
                 </table>
                 </div>
       </div>
     </div>
  </div><!--End Row-->
  </div><!--End MArket Content-->
