<div class="clearfix"></div>

  <div class="content-wrapper">
    <div class="container-fluid">
      <?php  if ($this->session->flashdata('msg')) {
        echo $this->session->flashdata("msg");
      }?>
  <!--Start Dashboard Content-->
  <div class="card mt-3">
    <div class="card-content">
        <div class="row row-group m-0">
            <div class="col-12 col-lg-6 col-xl-3 border-light">
                <div class="card-body">
                  <h5 class="text-white mb-0"><?=$this->session->ava_bal;?> <span class="float-right"><i class="fa fa-usd"></i></span></h5>
                    <div class="progress my-3" style="height:3px;">
                       <div class="progress-bar" style="width:100%"></div>
                    </div>
                  <p class="mb-0 text-white small-font">Current Balance
                    <?php
                    // if the user is due for receiving/selling
                    if ($this->session->cycle == 1) {?>
                    <span class="float-right">
                      <button
                        type="button"
                        <?php
                        // if the user has no pending merges
                        if($this->session->role != 1 AND $this->session->role != 2){?>
                          data-toggle="modal"
                          data-target="#sell-coins"
                        <?php }
                        // if he has pending sales or receiving transactions
                        else{ echo 'disabled'; }?>
                        class="btn-success">
                          Sell Coins
                      </button>
                    </span>
                    <?php }else{
                      if($this->session->role == 2){?>
                        <span class="float-right">
                      <button
                        type="button"
                        disabled
                        class="btn-success">
                          Sell Coins
                      </button>
                    </span>
                  <?php }else{?>
                    <span class="float-right">
                      <button
                        type="button"
                          data-toggle="modal"
                          data-target="#buy-coins"
                        class="btn-success">
                          Buy Coins
                      </button>
                    </span>
                  <?php } } ?>
                  </p>
                  <div class="modal fade" id="sell-coins" tabindex="-1" role="dialog" aria-labelledby="sell-coins">
                    <div class="modal-dialog" role="document">
                      <div class="modal-content bg-primary">
                        <div class="modal-header">
                          <p class="modal-title" id="coinModalLabel">Sell Coins</p>
                          <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                        </div>
                        <div class="modal-body">
                          <form action="<?=base_url('sell-coins')?>" method="post">
                            <div class="form-group">
                              <label for="qty" class="control-label">Quantity:</label>
                              <input type="text" name="qty" class="form-control" id="qty">
                            </div>
                            <button type="submit" class="btn btn-secondary btn-block">Submit</button>
                          </form>
                        </div>
                        <div class="modal-footer">
                          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="modal fade" id="buy-coins" tabindex="-1" role="dialog" aria-labelledby="buy-coins">
                    <div class="modal-dialog" role="document">
                      <div class="modal-content bg-primary">
                        <div class="modal-header">
                          <p class="modal-title" id="coinModalLabel">Buy Coins</p>
                          <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                        </div>
                        <div class="modal-body">
                          <form action="<?=base_url('buy-coins')?>" method="post">
                            <div class="form-group">
                              <label for="qty" class="control-label">Amount:</label>
                              <input type="text" name="qty" class="form-control" id="qty">
                            </div>
                            <button type="submit" class="btn btn-secondary btn-block">Submit</button>
                          </form>
                        </div>
                        <div class="modal-footer">
                          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
            </div>
            <div class="col-12 col-lg-6 col-xl-3 border-light">
                <div class="card-body">
                  <h5 class="text-white mb-0"><?=$this->session->book_bal;?> <span class="float-right"><i class="fa fa-usd"></i></span></h5>
                    <div class="progress my-3" style="height:3px;">
                       <div class="progress-bar" style="width:100%"></div>
                    </div>
                  <p class="mb-0 text-white small-font">Book Balance <span class="float-right">+1.2% <i class="zmdi zmdi-long-arrow-up"></i></span></p>
                </div>
            </div>
            <div class="col-12 col-lg-6 col-xl-3 border-light">
                <div class="card-body">
                  <h5 class="text-white mb-0">6200 <span class="float-right"><i class="fa fa-sitemap"></i></span></h5>
                    <div class="progress my-3" style="height:3px;">
                       <div class="progress-bar" style="width:100%"></div>
                    </div>
                  <p class="mb-0 text-white small-font">Referral Bonus <span class="float-right">+5.2% <i class="zmdi zmdi-long-arrow-up"></i></span></p>
                </div>
            </div>
            <div class="col-12 col-lg-6 col-xl-3 border-light">
                <div class="card-body">
                  <h5 class="text-white mb-0">5630 <span class="float-right"><i class="fa fa-usd"></i></span></h5>
                    <div class="progress my-3" style="height:3px;">
                       <div class="progress-bar" style="width:100%"></div>
                    </div>
                  <p class="mb-0 text-white small-font">Total Commission <span class="float-right">+2.2% <i class="zmdi zmdi-long-arrow-up"></i></span></p>
                </div>
            </div>
        </div>
    </div>
 </div>

  <div class="row">
     <div class="col-12 col-lg-12 col-xl-12">
      <div class="card">
     <div class="card-header">Bonic Coin Overview
       <div class="card-action">
       <div class="dropdown">

        </div>
       </div>
     </div>
     <div class="card-body">
        <ul class="list-inline">
        <li class="list-inline-item"><i class="fa fa-circle mr-2 text-white"></i>Bonic Coin</li>
        <!--<li class="list-inline-item"><i class="fa fa-circle mr-2 text-light"></i>Old Visitor</li>-->
      </ul>
      <div class="chart-container-1">
        <canvas id="chart1"></canvas>
      </div>
     </div>

     <div class="row m-0 row-group text-center border-top border-light-3">
       <div class="col-12 col-lg-4">
         <div class="p-3">
           <h5 class="mb-0">45.87M</h5>
         <small class="mb-0">Total Coins Mined <span> <i class="fa fa-arrow-up"></i> 2.43%</span></small>
         </div>
       </div>
       <div class="col-12 col-lg-4">
         <div class="p-3">
           <h5 class="mb-0">154801</h5>
         <small class="mb-0">Total Users <span> <i class="fa fa-arrow-up"></i> 12.65%</span></small>
         </div>
       </div>
       <div class="col-12 col-lg-4">
         <div class="p-3">
           <h5 class="mb-0">245012</h5>
         <small class="mb-0">Total Transactions <span> <i class="fa fa-arrow-up"></i> 5.62%</span></small>
         </div>
       </div>
     </div>

    </div>
   </div>
  </div><!--End Row-->

<div class="row">
     <div class="col-12 col-lg-12">
       <div class="card">
         <div class="card-header">Market Place Overview
        <div class="card-action">
               <div class="dropdown">
                <div class="dropdown-menu dropdown-menu-right">
                 </div>
                </div>
               </div>
       </div>
           <div class="table-responsive">
                   <table class="table align-items-center table-flush table-borderless">
                    <thead>
                     <tr>
                       <th>Username</th>
                       <th>Photo</th>
                       <th>Account</th>
                       <th>Amount</th>
                       <th>Progress</th>
                     </tr>
                     </thead>
                     <tbody>
                       <?php if (is_array($sellers)) {
                         foreach ($sellers as $seller) {
                           $user = $this->User_model->getUserbyId($seller['user_id']);
                           ?>
                           <tr>
                            <td><?=$user['rand']?></td>
                            <td><span class="user-profile"><img src="<?=config_item('base_url');?>dash/uploads/110.png" class="img-circle" alt=""></span></td>
                            <td><?=$user['acc_num']?></td>
                            <td>$<?=number_format($seller['amount'])?></td>
                            <td><div class="progress shadow" style="height: 3px;">
                                <div class="progress-bar" role="progressbar" style="width: 90%"></div>
                                </div>
                            </td>
                           </tr>
                         <?php } } ?>
                   </tbody>
                 </table>
                 </div>
       </div>
     </div>
  </div><!--End Row-->

      <!--End Dashboard Content-->
