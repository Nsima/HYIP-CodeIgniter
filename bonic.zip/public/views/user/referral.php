<div class="clearfix"></div>
<div class="content-wrapper">
  <div class="container-fluid">
    <div class="row justify-content-center">
      <div class="col-md-12">
        <div class="card">
          <div class="card-header">
            <?php $id = $this->session->rand; ?>
            <span>Referral link</span> <span class="pull-right"><?=base_url("signup?ref=$id")?></span>
            <?php if (($this->session->flashdata('message'))) {?>
              <div class="alert alert-dismissible">
                <p><?=$this->session->flashdata('message')?></p>
              </div>
          <?php } ?>
          </div>
          <div class="card-body">
            <div class="table-responsive">
              <table class="table table-striped">
                <thead>
                  Referral List
                </thead>
                <tr>
                  <th>S/NO</th>
                  <th>Name</th>
                  <th>Email</th>
                </tr>
                <tbody>
                  <?php if (is_array($referrals)) {
                    $count = 1;
                    foreach ($referrals as $ref) {?>
                  <tr>
                    <td><?=$count++?></td>
                    <td><?=$ref['name']?></td>
                    <td><?=$ref['email']?></td>
                  </tr>
                <?php } } ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
