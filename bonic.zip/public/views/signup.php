    <section class="error-area bg_cover" style="background-image: url(<?php echo config_item('base_url'); ?>assets/images/login-bg.jpg);">
        <div class="container">
            <div class="row">
                <div class="col-lg-5 col-md-8">
                    <div class="login-box">
                        <div class="login-title text-center">
                            <img src="<?php echo config_item('base_url'); ?>assets/images/logo-2.png" alt="logo">
                            <h3 class="title">Create an Account!</h3>
                        </div>
                        <center><?php echo $this->session->flashdata('verify_msg'); ?></center>
                        <div class="login-input">
                            <?php $attributes = array("name" => "registrationform"); echo form_open("signup", $attributes); ?>
                                <div class="input-box mt-10">
                                  <label for="referral">Referred By</label>
                                  <?php if(is_array($ref)){?>
                                    <input type="hidden" name="ref" value="<?php echo set_value('referral')?set_value('ref'):$ref['id']; ?>">
                                    <input id="referral" type="text" placeholder="referral" value="<?php echo set_value('referral')?set_value('referral'):$ref['name']; ?>" readonly name="referral">
                                  <?php }else{?>
                                    <input id="referral" type="text" placeholder="referral" readonly name="referral">
                                  <?php }?>
                                    <span class="text-danger"><?php echo form_error('referral'); ?></span>
                                </div>
                                <div class="input-box mt-10">
                                    <input type="text" placeholder="Name" value="<?php echo set_value('name'); ?>" name='name'>
                                    <input type="hidden" value="<?=$ref_id;?>" name="ref_id">
                                    <span class="text-danger"><?php echo form_error('name'); ?></span>
                                </div>
                                <div class="input-box mt-10">
                                    <input type="text" placeholder="Email" value="<?php echo set_value('email'); ?>" name='email'>
                                    <span class="text-danger"><?php echo form_error('email'); ?></span>
                                </div>
                                <div class="input-box mt-10">
                                    <select class="form-control input-lg" onchange="print_state('state', this.selectedIndex);" id="country" required  name="country" value="<?php echo set_value('country'); ?>"/></select>
                                    <script language="javascript">print_country("country");</script>
                                    <span class="text-danger"><?php echo form_error('country'); ?></span>
                                </div>
                                <div class="input-box mt-10">
                                    <select  name ="state" required=""  id ="state" class="input-box form-control"><option value="<?php echo set_value('state'); ?>">Select state</option></select>
                                    <span class="text-danger"><?php echo form_error('state'); ?></span>
                                </div>
                                <div class="input-box mt-10">
                                    <input type="password" name="password" placeholder="Password">
                                    <span class="text-danger"><?php echo form_error('password'); ?></span>
                                    <ul class="checkbox_common checkbox_style5">
                                        <li>
                                            <input type="checkbox" name="checkbox5" id="checkbox13">
                                            <label for="checkbox13"><span></span>I agree to the Terms of Service and Privacy Policy</label>
                                        </li>
                                    </ul>
                                </div>
                                <div class="input-btn mt-10">
                                    <button class="main-btn" type="submit">Signup  <i class="fal fa-arrow-right"></i></button>
                                    <?php echo form_close(); ?>
                                    <br>
                                    <center><span class="bg-primary" style="color:white; text-align:center"><?php echo $this->session->flashdata('msg'); ?></span></center>
                                    <span>Already have an account? <a href="login">Singin</a></span>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
